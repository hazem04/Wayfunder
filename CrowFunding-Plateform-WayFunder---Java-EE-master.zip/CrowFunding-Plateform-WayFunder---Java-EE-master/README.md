About The Project:

A Fully Functional Crowdfunding plateform (kickstarter clone)


Built with: 

HTML, 
CSS, 
JavaScript, 
java Enterprise edition
